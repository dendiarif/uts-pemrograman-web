<?php

function potongArtikel($artikel, $wordLimit, $idArtikel){
    //pisahkan setiap kata lalu buat jadi array
    $word = explode(" ", $artikel);
    //Gabung kata jadi artikel by wordLimit
    $result = implode(" ",array_slice($word,0,$wordLimit));

    if(count($word) > $wordLimit){
        $result .= '<p>
                        <a href="blog-artikel.php?id='.$idArtikel.'">
                        Read More
                        </a>
                    </p>';
    }
    return $result;

}

?>