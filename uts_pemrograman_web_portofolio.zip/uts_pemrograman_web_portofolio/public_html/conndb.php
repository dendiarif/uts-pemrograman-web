<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "portofolio_saya";

//Buat Koneksi
$conn = mysqli_connect($serverName, $userName, $password, $dbName);

//cek koneksi
if(!$conn){
    die("Koneksi Gagal");
}

?>