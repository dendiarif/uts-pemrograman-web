<?php
header('Access-Control-Allow_Origin:*');
header('Content-Type: application/json');

include "conndb.php";
//include "fungsi.php";

$id = (isset($_GET["id"])? $_GET["id"] : 0);

$sql = 'SELECT * FROM data_portofolio where id='.$id;

$result = mysqli_query($conn,$sql);

$data=array();

$jmlData = mysqli_num_rows($result);

if ($jmlData >0){
    $row = mysqli_fetch_assoc($result);
    $data = $row;
}else{
    $data['error'] = 'Data Tidak ditemukan atau invalid id';
}
echo json_encode($data);
?>