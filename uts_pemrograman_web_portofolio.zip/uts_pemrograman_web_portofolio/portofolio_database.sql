/*
SQLyog Community v11.1 (32 bit)
MySQL - 5.5.5-10.1.38-MariaDB : Database - portofolio_saya
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `data_portofolio` */

DROP TABLE IF EXISTS `data_portofolio`;

CREATE TABLE `data_portofolio` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `menu` varchar(50) NOT NULL COMMENT 'Menu',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='Tabel portofolio';

/*Data for the table `data_portofolio` */

LOCK TABLES `data_portofolio` WRITE;

insert  into `data_portofolio`(`id`,`menu`,`judul`,`subjudul`,`tgl`,`gbr`,`isi`) values (1,'home','Selamat Datang di website portofolio saya','Dendi Arif Wicaksono','2023-10-31 19:57:26','assets/imgs/home.jpeg',''),(2,'tentang','Dendi Arif Wicaksono','Mahasiswa Aktif','2023-10-31 20:02:33','assets/imgs/avatar-4.jpg','<p>Nama : Dendi </p>\r\n<p>Alamat : Jakarta</p>\r\n<p>Kampus : Universitas Pembangunan Jaya</p>\r\n<p>Jurusan : Informatika</p>'),(3,'skill','Skill','Beberapa Skill Saya','2023-10-31 20:32:13','','<div class=\"row text-left\">\r\n<div class=\"col-sm-6\">\r\n    <h6 class=\"mb-3\">Photoshop</h6>\r\n    <div class=\"progress\">\r\n        <div class=\"progress-bar bg-primary\" role=\"progressbar\" style=\"width: 89%;\" aria-valuenow=\"25\" aria-valuemin=\"0\" aria-valuemax=\"100\"><span>89%</span></div>\r\n    </div>\r\n</div>\r\n<div class=\"col-sm-6\">\r\n    <h6 class=\"mb-3\">Web Design</h6>\r\n    <div class=\"progress\">\r\n        <div class=\"progress-bar bg-primary\" role=\"progressbar\" style=\"width: 83%;\" aria-valuenow=\"25\" aria-valuemin=\"0\" aria-valuemax=\"100\"><span>83%</span></div>\r\n    </div>\r\n</div>\r\n<div class=\"col-sm-6\">\r\n    <h6 class=\"mb-3\">App Design</h6>\r\n    <div class=\"progress\">\r\n        <div class=\"progress-bar bg-primary\" role=\"progressbar\" style=\"width: 95%;\" aria-valuenow=\"25\" aria-valuemin=\"0\" aria-valuemax=\"100\"><span>95%</span></div>\r\n    </div>\r\n</div>\r\n<div class=\"col-sm-6\">\r\n    <h6 class=\"mb-3\">SEO</h6>\r\n    <div class=\"progress\">\r\n        <div class=\"progress-bar bg-primary\" role=\"progressbar\" style=\"width: 90%;\" aria-valuenow=\"25\" aria-valuemin=\"0\" aria-valuemax=\"100\"><span>90%</span></div>\r\n    </div>\r\n</div>'),(4,'blog','Lorem Ipsum','Apakah Lorem Ipsum itu?','2023-10-31 20:59:49','assets/imgs/blog-1.jpg','Lorem Ipsum adalah contoh teks atau dummy dalam industri percetakan dan penataan huruf atau typesetting. Lorem Ipsum telah menjadi standar contoh teks sejak tahun 1500an, saat seorang tukang cetak yang tidak dikenal mengambil sebuah kumpulan teks dan mengacaknya untuk menjadi sebuah buku contoh huruf. Ia tidak hanya bertahan selama 5 abad, tapi juga telah beralih ke penataan huruf elektronik, tanpa ada perubahan apapun. Ia mulai dipopulerkan pada tahun 1960 dengan diluncurkannya lembaran-lembaran Letraset yang menggunakan kalimat-kalimat dari Lorem Ipsum, dan seiring munculnya perangkat lunak Desktop Publishing seperti Aldus PageMaker juga memiliki versi Lorem Ipsum.'),(5,'blog','Lorem Ipsum','Dari mana asalnya?','2023-10-31 20:59:55','assets/imgs/blog-2.jpg','Tidak seperti anggapan banyak orang, Lorem Ipsum bukanlah teks-teks yang diacak. Ia berakar dari sebuah naskah sastra latin klasik dari era 45 sebelum masehi, hingga bisa dipastikan usianya telah mencapai lebih dari 2000 tahun. Richard McClintock, seorang professor Bahasa Latin dari Hampden-Sidney College di Virginia, mencoba mencari makna salah satu kata latin yang dianggap paling tidak jelas, yakni consectetur, yang diambil dari salah satu bagian Lorem Ipsum. Setelah ia mencari maknanya di di literatur klasik, ia mendapatkan sebuah sumber yang tidak bisa diragukan. Lorem Ipsum berasal dari bagian 1.10.32 dan 1.10.33 dari naskah \"de Finibus Bonorum et Malorum\" (Sisi Ekstrim dari Kebaikan dan Kejahatan) karya Cicero, yang ditulis pada tahun 45 sebelum masehi.'),(6,'blog','Lorem Ipsum','Mengapa kita menggunakannya?','2023-10-31 21:00:34','assets/imgs/blog-3.jpg','Sudah merupakan fakta bahwa seorang pembaca akan terpengaruh oleh isi tulisan dari sebuah halaman saat ia melihat tata letaknya. Maksud penggunaan Lorem Ipsum adalah karena ia kurang lebih memiliki penyebaran huruf yang normal, ketimbang menggunakan kalimat seperti \"Bagian isi disini, bagian isi disini\", sehingga ia seolah menjadi naskah Inggris yang bisa dibaca. Banyak paket Desktop Publishing dan editor situs web yang kini menggunakan Lorem Ipsum sebagai contoh teks. Karenanya pencarian terhadap kalimat \"Lorem Ipsum\" akan berujung pada banyak situs web yang masih dalam tahap pengembangan. Berbagai versi juga telah berubah dari tahun ke tahun, kadang karena tidak sengaja, kadang karena disengaja (misalnya karena dimasukkan unsur humor atau semacamnya)'),(7,'kontak','Kontak Saya','','2023-10-31 22:10:00','assets/imgs/avatar-4.jpg',' <div class=\"item\">\r\n <i class=\"ti-location-pin\"></i>\r\n <div class=\"\">\r\n     <h5>Lokasi</h5>\r\n     <p>Jakarta, Indonesia</p>\r\n </div>   \r\n                    </div>\r\n                    <div class=\"item\">\r\n <i class=\"ti-mobile\"></i>\r\n <div>\r\n     <h5>Telephone</h5>\r\n     <p>082246489784</p>\r\n </div>   \r\n                    </div>\r\n                    <div class=\"item\">\r\n <i class=\"ti-email\"></i>\r\n <div class=\"mb-0\">\r\n     <h5>Alamat Email</h5>\r\n     <p>DendiArif15@gmail.com</p>\r\n </div>\r\n                    </div>');

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
